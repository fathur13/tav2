@php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->status_air ;
    }
@endphp