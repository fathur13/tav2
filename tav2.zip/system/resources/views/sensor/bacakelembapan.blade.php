@php
    foreach ($nilaisensor as $data) {
        # baca data kelembapan 
        echo $data->kelembapan ;
    }
@endphp