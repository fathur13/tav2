@php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->suhu ;
    }
@endphp