<?php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->status_air ;
    }
?><?php /**PATH C:\xampp\htdocs\tav2\system\resources\views/sensor/bacacuaca.blade.php ENDPATH**/ ?>