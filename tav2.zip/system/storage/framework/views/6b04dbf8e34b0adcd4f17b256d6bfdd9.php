<?php
    foreach ($nilaisensor as $data) {
        # baca data kelembapan 
        echo $data->kelembapan ;
    }
?><?php /**PATH C:\xampp\htdocs\tav2\system\resources\views/sensor/bacakelembapan.blade.php ENDPATH**/ ?>