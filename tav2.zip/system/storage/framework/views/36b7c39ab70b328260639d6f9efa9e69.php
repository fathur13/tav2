<?php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->suhu ;
    }
?><?php /**PATH C:\xampp\htdocs\tav2\system\resources\views/sensor/bacasuhu.blade.php ENDPATH**/ ?>