<div class="sidebar-wrapper">
    <div class="sidebar sidebar-collapse" id="sidebar">
        <div class="sidebar__menu-group">
            <ul class="sidebar_nav">
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>" class="<?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                        <span class="nav-icon uil uil-calendar-alt"></span>
                        <span class="menu-text">Dashboard</span>
                    </a>
                </li>
                <li class="has-child <?php echo e(Request::is('ketinggian_air', 'suhu', 'kelembapan', 'cuaca') ? 'open' : ''); ?>">
                    <a href="#"
                        class="<?php echo e(Request::is('ketinggian_air', 'suhu', 'kelembapan', 'cuaca') ? 'active' : ''); ?>">
                        <span class="nav-icon uil uil-window-section"></span>
                        <span class="menu-text">Data</span>
                        <span class="toggle-icon"></span>
                    </a>
                    <ul>
                        <li>
                            <a href="<?php echo e('ketinggian_air'); ?>"
                                class="<?php echo e(Request::is('ketinggian_air') ? 'active' : ''); ?>">Ketinggian Air</a>
                        </li>
                        <li>
                            <a href="<?php echo e('suhu'); ?>" class="<?php echo e(Request::is('suhu') ? 'active' : ''); ?>">Suhu</a>
                        </li>
                        <li>
                            <a href="<?php echo e('kelembapan'); ?>"
                                class="<?php echo e(Request::is('kelembapan') ? 'active' : ''); ?>">kelembapan</a>
                        </li>
                        <li>
                            <a href="<?php echo e('cuaca'); ?>" class="<?php echo e(Request::is('cuaca') ? 'active' : ''); ?>">cuaca</a>
                        </li>
                    </ul>
                </li>
                <li class="menu-title mt-30">
                    <span>Applications</span>
                </li>
                <li class="has-child <?php echo e(Request::is('public_api') ? 'open' : ''); ?>">
                    <a href="#" 
                    class="<?php echo e(Request::is('public_api') ? 'active' : ''); ?>">
                        <span class="nav-icon uil uil-envelope"></span>
                        <span class="menu-text">API</span>
                        <span class="toggle-icon"></span>
                    </a>
                    <ul>
                        <li class>
                            <a href="<?php echo e(url('public_api')); ?>" class="<?php echo e(Request::is('public_api') ? 'active' : ''); ?>">Public API</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(url('report')); ?>" class="<?php echo e(Request::is('report') ? 'active' : ''); ?>">
                        <span class="nav-icon uil uil-window-section"></span>
                        <span class="menu-text">Report</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\tav2\system\resources\views/layouts/section/sidebar.blade.php ENDPATH**/ ?>