<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

// Membuat dataset
$data = [
    ['tanggung_jawab' => 1, 'kedisiplinan' => 1, 'kerjasama' => 1, 'kontrak_kerja' => 'ya'],
    ['tanggung_jawab' => 1, 'kedisiplinan' => 0, 'kerjasama' => 1, 'kontrak_kerja' => 'ya'],
    ['tanggung_jawab' => 1, 'kedisiplinan' => 1, 'kerjasama' => 0, 'kontrak_kerja' => 'ya'],
    ['tanggung_jawab' => 0, 'kedisiplinan' => 0, 'kerjasama' => 1, 'kontrak_kerja' => 'tidak'],
    ['tanggung_jawab' => 0, 'kedisiplinan' => 1, 'kerjasama' => 0, 'kontrak_kerja' => 'tidak'],
    ['tanggung_jawab' => 0, 'kedisiplinan' => 0, 'kerjasama' => 0, 'kontrak_kerja' => 'tidak']
];

// Membuat fungsi untuk menghitung layak atau tidaknya seseorang untuk memperpanjang kontrak kerja
function layak_perpanjang_kontrak($tanggung_jawab, $kedisiplinan, $kerjasama) {
    if ($tanggung_jawab == 1 && $kedisiplinan == 1 && $kerjasama == 1) {
        return "ya";
    } else {
        return "tidak";
    }
}

// Mengecek apakah form telah disubmit
if (isset($_POST['submit'])) {
    // Mengambil nilai tanggung jawab, kedisiplinan, dan kerjasama dari form
    $tanggung_jawab = $_POST['tanggung_jawab'];
    $kedisiplinan = $_POST['kedisiplinan'];
    $kerjasama = $_POST['kerjasama'];

    // Memprediksi apakah seseorang layak atau tidak untuk memperpanjang kontrak kerja
    $hasil = layak_perpanjang_kontrak($tanggung_jawab, $kedisiplinan, $kerjasama);
}

?>

<!-- Membuat form untuk memasukkan nilai tanggung jawab, kedisiplinan, dan kerjasama -->
<form method="post">
    <label for="tanggung_jawab">Tanggung Jawab:</label><br>
    <input type="radio" id="tanggung_jawab_ya" name="tanggung_jawab" value="1">
    <label for="tanggung_jawab_ya">Ya</label><br>
    <input type="radio" id="tanggung_jawab_tidak" name="tanggung_jawab" value="0">
    <label for="tanggung_jawab_tidak">Tidak</label><br><br>

    <label for="kedisiplinan">Kedisiplinan:</label><br>
    <input type="radio" id="kedisiplinan_ya" name="kedisiplinan" value="1">
    <label for="kedisiplinan_ya">Ya</label><br>
    <input type="radio" id="kedisiplinan_tidak" name="kedisiplinan" value="0">
    <label for="kedisiplinan_tidak">Tidak</label><br><br>

    <label for="kerjasama">Kerjasama:</label><br>
    <input type="radio" id="kerjasama_ya" name="kerjasama" value="1">
    <label for="kerjasama_ya">Ya</label><br>
    <input type="radio" id="kerjasama_tidak" name="kerjasama" value="0">
    <label for="kerjasama_tidak">Tidak</label><br><br>

    <input type="submit" name="submit" value="Submit">
</form>

<?php
// Mengecek apakah hasil prediksi sudah ada
if (isset($hasil)) {
    echo "<h2>Hasil Prediksi:</h2>";
    echo "Layak memperpanjang kontrak kerja: " . $hasil;
}
?>

</body>
</html><?php /**PATH C:\xampp\htdocs\TAv2\system\resources\views/oka.blade.php ENDPATH**/ ?>