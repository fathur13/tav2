<?php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->suhu ;
    }
?><?php /**PATH C:\xampp\htdocs\TAv2\system\resources\views/sensor/bacasuhu.blade.php ENDPATH**/ ?>