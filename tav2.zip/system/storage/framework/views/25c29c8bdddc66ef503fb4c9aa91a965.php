<!DOCTYPE html>
<html>
<head>
    <title>Peta LEFTel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css" />
    <style>
        #map {
            height: 400px;
        }
        .frame {
            border: 2px solid black;
            width: 420px;
            height: 420px;
            position: relative;
            margin: auto;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="frame">
        <div id="map"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        var map = L.map('map').setView([-1.845277, 109.966761], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);

        var marker = L.marker([-1.845277, 109.966761]).addTo(map);
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\TAv2\system\resources\views/map.blade.php ENDPATH**/ ?>