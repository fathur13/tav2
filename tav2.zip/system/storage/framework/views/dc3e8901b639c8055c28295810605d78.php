<?php
    foreach ($nilaisensor as $data) {
        //cetak isi kelembapan
        echo $data->status_air ;
    }
?><?php /**PATH C:\xampp\htdocs\TAv2\system\resources\views/sensor/bacacuaca.blade.php ENDPATH**/ ?>